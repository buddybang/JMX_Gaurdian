package com.tristha.licensetool;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Base64;

/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  Tristha JMX Sentinel — License Generation Tool  (INTERNAL USE ONLY)       ║
 * ║                                                                              ║
 * ║  NEVER DISTRIBUTE THIS JAR.  It contains the RSA private key.               ║
 * ║  Only the product JAR (tristha-jmx-sentinel.jar) goes to clients.           ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * Generates a cryptographically-signed Tristha license file (.lic).
 * Signing uses RSA-SHA256 with a 2048-bit key embedded in this tool.
 * The product JAR validates using the corresponding PUBLIC key only.
 *
 * Usage:
 *   java -jar tristha-license-tool.jar \
 *        --client   "Jaywan Testing Services" \
 *        --id       JAYWAN-001 \
 *        --expiry   2026-12-31 \
 *        --users    10 \
 *        --hosts    JAYWAN-PC01,192.168.10.42   (optional — node-lock) \
 *        --features ALL                         (optional — default: ALL) \
 *        --out      jaywan.lic                  (optional — default: tristha.lic)
 *
 * After generating:
 *   1. cp <output>.lic  sentinel-v61/src/main/resources/META-INF/tristha.lic
 *   2. mvn clean package  (in the sentinel-v61 project)
 *   3. Deliver the JAR to the client — license is embedded; no separate file needed.
 */
public class TristhaLicenseTool {

    // ── RSA Private Key — PKCS#8 DER — Base64 encoded ─────────────────────────
    // Generated 2048-bit key.  This tool never ships to clients.
    private static final String PRIVATE_KEY_B64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC5+MXmSbOmlsRhyCI5SxktpoycTJVjanR+WjQQ0BRxnlG2xdUGsYxudFujnUXZILS6Xu5z2bEgeQae7LBL97EJ0NqZ+TgbfCcP5a3AyD1b85jpGODH4Md3LKPu3a3RMIItlkcHbKuBTbjO4O0RgmoWGMCNijB2I0YDlHc7rjDeJ2J6hUZ5hIkciGySrLQ/WgT0lysvu0klPirl2FM53IMRCDZdMUZ8/jOEPnd+RTjzNM4AD9bnXJTflQiJIcE9av4wosOBJ+++RPclbl33lBD+kQTZ5qPap/sn2vQHS86+0Hy6yxWDJy2R3JVtFi7i22lyA9speHpaApHQPmfsa9SDAgMBAAECggEAGt6r0UsiztYHx8z/zOFh4Ouoc0jJaNTPwhXMYgV+frAORGcvEUmD7c2YE/q8RdPo6OigcVKpufRilYHDMya1iKKJgye0CJyWlEBuK2WDIA8BL+StTZPXngtwICodXBUzKd0FpDf6S7NsGU/8UMRUCZ9H6utldxw/mHLSC2hunRo6dOxyWvk270VGWoYdDGT7a94zP9GbJcYKP0BGvxPnFWOe7a9wIOAKcMZP9IbdEoNVPR7sPQ4hTc/MpeiweN9B3V8jI/RfzyXJaTEJR4GsnDiU/zaACPRtI/mUKJ4tVQkw3+I3iqhLzqhGPlYn7yYJfJvv2Waxc/iPx3FG7/SesQKBgQDqVmy48YDJe/MY8pS0ZXZRm8O5Y1hqnKz9LYIq3fGixBtX5vqYzZusS0VM1SvcptxrcK8areA3XjUykVQYLGwITUL8AxqPFwzSDg90JnApgvu61sFjqt0puZPg5Xp5Oayb1+OQ1fCSdoFThGXVDcSL0M5HEEn6GA/zuizaT+oTewKBgQDLKcanjiLlYgRtEkCeUe042k9DrNbvGJSjeq5m4f8YLNeObZs6lgxGsY8IP6NcbFgs6MDPXcjdw4cUPSP5iUHvTTD+bR0zI2Cu5GxyCNyioDz8J8PqeLjIY9l4BgsHhELIVgT5vn5RmS2K/yUHeUb4z1/nYsjupysn3AWKAmOQmQKBgQCEbnUhC7KZq0fWCHmLfW+hbSLuaTt1fLeymP5gFW/SaXt+cNWcd04Lz7oJUstn9pDI0zTSIgN9purvefwJcUlYY7mATIy84uzm5PVM0dA/VXvHukgueEhmpS7yQR221qY6qIY9uvoq+3fY6BDYl+BEl6uLs6PrB6A0QDnK4rDJcwKBgGFl7soHV2121z5fIMGF719xMcz1ALnxo9jYCOJj+ELjxJeQrnmg09PUbgj7UVsOyhsFnuILSTAf/BNU2HlaN1T9Qb7IGtaYYFKYSfFFlFkWzwXoHoG7TIMtc2WaKBF7c/TNYGdGzxJZiD754Qu7Na405PpuHnxjgkoCrlkimg8JAoGACHRhzDCtOq/HD9V/WIptlB/EGJ2SUaRPwHNjC2+YFEJCb4QDgt7+mpDu7m8EUWAQXRNRSOUWe65d0VkZFVa1Kx0FyvD57kFiPQYv6Ve7Ea5Onliegz8JYO9AFZ019/TUKk9eFGfNWg664I057dNapDn3FLc2opC8FyXq5i3Ags8=";

    public static void main(String[] args) throws Exception {
        String clientName = null;
        String clientId   = null;
        String expiry     = null;
        String maxUsers   = "5";
        String allowedHosts = "";
        String features   = "ALL";
        String outFile    = "tristha.lic";
        String issuedBy   = "Tristha Technology Consulting";

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--client":   clientName   = nextArg(args, i++); break;
                case "--id":       clientId     = nextArg(args, i++); break;
                case "--expiry":   expiry       = nextArg(args, i++); break;
                case "--users":    maxUsers     = nextArg(args, i++); break;
                case "--hosts":    allowedHosts = nextArg(args, i++); break;
                case "--features": features     = nextArg(args, i++); break;
                case "--out":      outFile      = nextArg(args, i++); break;
                case "--issuedby": issuedBy     = nextArg(args, i++); break;
                case "--help": case "-h": printUsage(); return;
            }
        }

        // ── Validation ────────────────────────────────────────────────────────
        if (clientName == null) die("--client is required");
        if (clientId   == null) die("--id is required");
        if (expiry     == null) die("--expiry is required (YYYY-MM-DD)");

        LocalDate expiryDate;
        try {
            expiryDate = LocalDate.parse(expiry);
        } catch (DateTimeParseException e) {
            die("--expiry must be YYYY-MM-DD (e.g. 2027-03-31)");
            return;
        }

        int maxUsersInt;
        try {
            maxUsersInt = Integer.parseInt(maxUsers.trim());
            if (maxUsersInt < 0) die("--users must be a non-negative integer");
        } catch (NumberFormatException e) {
            die("--users must be an integer"); return;
        }

        String issuedDate = LocalDate.now().toString();

        if (expiryDate.isBefore(LocalDate.now())) {
            System.err.println("WARNING: Expiry date " + expiry + " is already in the past!");
        }

        // ── Build canonical payload ───────────────────────────────────────────
        String payload = buildPayload(clientName, clientId, expiry,
                                      issuedDate, issuedBy, maxUsersInt,
                                      allowedHosts.trim(), features.trim());

        // ── Sign with RSA private key ─────────────────────────────────────────
        String signature = sign(payload);

        // ── Write .lic file ───────────────────────────────────────────────────
        StringBuilder lic = new StringBuilder();
        lic.append("# Tristha JMX Sentinel — License File\n");
        lic.append("# Generated  : ").append(issuedDate).append("\n");
        lic.append("# WARNING    : Do not edit — RSA signature will be invalidated.\n");
        lic.append("#\n");
        lic.append("client.name=").append(clientName).append("\n");
        lic.append("client.id=").append(clientId).append("\n");
        lic.append("expiry.date=").append(expiry).append("\n");
        lic.append("issued.date=").append(issuedDate).append("\n");
        lic.append("issued.by=").append(issuedBy).append("\n");
        lic.append("max.users=").append(maxUsersInt).append("\n");
        lic.append("allowed.hosts=").append(allowedHosts.trim()).append("\n");
        lic.append("features=").append(features.trim()).append("\n");
        lic.append("signature=").append(signature).append("\n");

        Files.write(Paths.get(outFile),
                    lic.toString().getBytes(StandardCharsets.UTF_8));

        // ── Success banner ────────────────────────────────────────────────────
        long daysValid = expiryDate.toEpochDay() - LocalDate.now().toEpochDay();
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║   Tristha JMX Sentinel — License Generated (RSA-SHA256)          ║");
        System.out.println("╠══════════════════════════════════════════════════════════════════╣");
        System.out.println("║  Client   : " + pad(clientName, 53) + "║");
        System.out.println("║  ID       : " + pad(clientId,   53) + "║");
        System.out.println("║  Expiry   : " + pad(expiry + "  (" + daysValid + " days)", 53) + "║");
        System.out.println("║  Max Users: " + pad(maxUsersInt == 0 ? "unlimited" : String.valueOf(maxUsersInt), 53) + "║");
        System.out.println("║  Hosts    : " + pad(allowedHosts.isEmpty() ? "(any — no node-lock)" : allowedHosts, 53) + "║");
        System.out.println("║  Features : " + pad(features, 53) + "║");
        System.out.println("╠══════════════════════════════════════════════════════════════════╣");
        System.out.println("║  Output   : " + pad(outFile, 53) + "║");
        System.out.println("╠══════════════════════════════════════════════════════════════════╣");
        System.out.println("║  NEXT STEPS:                                                     ║");
        System.out.println("║  1. cp " + outFile + "  sentinel-v61/src/main/resources/META-INF/tristha.lic");
        System.out.println("║  2. cd sentinel-v61 && mvn clean package                         ║");
        System.out.println("║  3. Deliver target/tristha-jmx-sentinel-*.jar to client          ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝");
        System.out.println();
    }

    // ── RSA Signing ───────────────────────────────────────────────────────────

    static String buildPayload(String clientName, String clientId,
                                String expiryDate, String issuedDate,
                                String issuedBy, int maxUsers,
                                String allowedHosts, String features) {
        return clientName + "|" + clientId + "|" + expiryDate + "|"
             + issuedDate + "|" + issuedBy + "|" + maxUsers + "|"
             + allowedHosts + "|" + features;
    }

    private static String sign(String payload) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(PRIVATE_KEY_B64);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        PrivateKey privateKey = KeyFactory.getInstance("RSA").generatePrivate(spec);

        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(privateKey, new SecureRandom());
        sig.update(payload.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static String nextArg(String[] args, int i) {
        if (i + 1 >= args.length) die("Missing value after " + args[i]);
        return args[i + 1];
    }

    private static String pad(String s, int width) {
        if (s == null) s = "";
        if (s.length() >= width) return s.substring(0, width);
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < width) sb.append(' ');
        return sb.toString();
    }

    private static void die(String msg) {
        System.err.println("ERROR: " + msg);
        printUsage();
        System.exit(1);
    }

    private static void printUsage() {
        System.out.println();
        System.out.println("Tristha JMX Sentinel — License Generation Tool");
        System.out.println();
        System.out.println("Usage:");
        System.out.println("  java -jar tristha-license-tool.jar \");
        System.out.println("       --client   \"Client Name\"      \");
        System.out.println("       --id       CLIENT-001         \");
        System.out.println("       --expiry   YYYY-MM-DD         \");
        System.out.println("       --users    10                 \");
        System.out.println("       --hosts    PC01,192.168.1.5   (optional) \");
        System.out.println("       --features ALL                (optional) \");
        System.out.println("       --out      client.lic         (optional)");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  java -jar tristha-license-tool.jar --client \"Jaywan Bank\" --id JB-001 --expiry 2026-12-31 --users 10");
        System.out.println("  java -jar tristha-license-tool.jar --client \"Acme Corp\" --id ACME-002 --expiry 2026-06-30 --users 3 --hosts ACME-SRV01,10.0.1.5");
        System.out.println("  java -jar tristha-license-tool.jar --client \"NBAD\" --id NBAD-003 --expiry 2027-03-31 --users 20 --out nbad.lic");
    }
}
