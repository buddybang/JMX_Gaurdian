# Tristha License Tool — INTERNAL USE ONLY

> **⚠ NEVER DISTRIBUTE THIS JAR TO CLIENTS.**  
> It contains the RSA private key used to sign licenses.

---

## Architecture

```
You (Tristha internal)                    Client machine
──────────────────────────────────────    ──────────────────────────────────
tristha-license-tool.jar                  tristha-jmx-sentinel-*.jar
  └── RSA PRIVATE KEY (2048-bit)   ────►    └── RSA PUBLIC KEY only
        Signs .lic files                          Verifies signature
        Never ships to clients                    Cannot forge a license
```

Even if a client fully decompiles the product JAR, they only find the **public key** — which is cryptographically useless for forging a license. The private key never leaves your machine.

---

## Generating a License

```bash
java -jar tristha-license-tool.jar \
     --client   "Jaywan Testing Services" \
     --id       JAYWAN-001 \
     --expiry   2026-12-31 \
     --users    10 \
     --hosts    JAYWAN-PC01,192.168.10.42 \
     --out      jaywan.lic
```

| Parameter   | Required | Description |
|-------------|----------|-------------|
| `--client`  | ✅       | Human-readable client/org name (shown in UI) |
| `--id`      | ✅       | Unique client identifier (e.g. `JAYWAN-001`) |
| `--expiry`  | ✅       | License expiry date: `YYYY-MM-DD` |
| `--users`   | ❌       | Max concurrent logins (default: 5; 0 = unlimited) |
| `--hosts`   | ❌       | Comma-separated hostnames/IPs for node-lock |
| `--features`| ❌       | Feature set: `ALL` or comma-separated codes |
| `--out`     | ❌       | Output filename (default: `tristha.lic`) |

### License duration examples

| Scenario       | Expiry flag        |
|----------------|--------------------|
| 3-month trial  | `--expiry 2026-06-13` |
| 6-month term   | `--expiry 2026-09-13` |
| 1-year term    | `--expiry 2027-03-13` |
| 2-year term    | `--expiry 2028-03-13` |
| Perpetual      | `--expiry 2099-12-31` |

---

## Deploying the License

After generating the `.lic` file:

```bash
# 1. Embed in the product build
cp jaywan.lic  sentinel-v61/src/main/resources/META-INF/tristha.lic

# 2. Build the client JAR
cd sentinel-v61
mvn clean package -q

# 3. Deliver to client
#    target/tristha-jmx-sentinel-*.jar
#    (license is embedded — no separate .lic file to manage)
```

---

## What the product enforces

| Check | Behaviour |
|-------|-----------|
| RSA signature | App refuses to start if tampered |
| Expiry date | Warning banner 30 days before expiry; 7-day grace period after |
| Node-lock (optional) | Blocks login if hostname/IP not in `allowed.hosts` |
| Concurrent users | Blocks login when active sessions ≥ `max.users` |

---

## Building this tool

```bash
mvn clean package -q
# → target/tristha-license-tool.jar
```

Keep `tristha-license-tool.jar` and the source on a secured internal machine only.
